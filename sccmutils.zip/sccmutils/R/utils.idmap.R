#' liftOver genomic coordinates from human genome version hg38 to genome version hg19
#'
#' @param gObj genectic object with genomic coordinates in hg38 version.
#' @return gObj_ with transferred genomic coordinates in hg19 version.
#' @export
liftOver_hg38tohg19_GRanges = function(gObj){
  suppressMessages(require(rtracklayer))
  suppressMessages(require(liftOver))
  ## load resource
  path = system.file(package="liftOver", "extdata", "hg38ToHg19.over.chain")
  ch = import.chain(path)
  GenomeInfoDb::seqlevelsStyle(gObj) = "UCSC"
  gObj_ = rtracklayer::liftOver(gObj, ch)
  gObj_ = unlist(gObj_)
  GenomeInfoDb::genome(gObj_) = "hg19"
  return(gObj_)
}


#' generate gene length based on a given gtf annotation file
#'
#' requires rtracklayer package to read in gtf/gff file.
#' @param gtf_filepath File path of gtf annotation
#' @return a data.frame with columns of gene_id, the chromosome position, the start position, the end position of genes
#' @export
generate_gene_length = function(gtf_filepath){
  annotation = rtracklayer::readGFF(gtf_filepath)
  result = annotation %>%
    dplyr::group_by(gene_id) %>%
    dplyr::filter(end == max(end) | start == min(start) ) %>%
    dplyr::mutate(group_end = max(end), group_start = min(start), length = group_end - group_start) %>%
    dplyr::select(gene_id, seqid, group_start, group_end, length) %>%
    dplyr::distinct()
  return(result)
}


#' Fill in features that fail to find a corresponding element with the original element.
#'
#' @param mappedlist A mapped list with values as the target elements and names the corresponding original elements.
#' @param from The original id system of the input elements.
#' @param to The target id system (like SYMBOL, REFSEQ).
#' @param remove A boolean variable to decide whether remove elements without mapped ids. Default value is False.
#' @return translated list with NA features filled with original elements.
#' @export
trans_features = function(mappedlist, from, to, remove=F){
  tran_list = named_vec(mappedlist[,from],mappedlist[,to])
  tran_list[is.na(tran_list)] = mappedlist[is.na(tran_list),from]
  if (remove){
    tran_list = tran_list[-is.na(tran_list)]
  }
  return(tran_list)
}


#' Transfer features from one id system to another id system.
#'
#' @param glist A vector of gene ids from one id system (such as ENSEMBL, ENTREZ, ACCNUM).
#' @param species The organism of the gene ids used.
#' @param from The original id system of the input elements.
#' @param to The target id system (like SYMBOL, REFSEQ).
#' @return return a mapped list, whose values are the target ids and names are the orignal ids.
#' @export
match_geneids = function(glist, species, from, to){
  if (species=="human"){
    dbs=org.Hs.eg.db::org.Hs.eg.db
  } else {
    dbs=org.Mm.eg.db::org.Mm.eg.db
  }
  mapped_glist = AnnotationDbi::select(dbs, keys=glist, columns=c(from,to), keytype=from)
  return(mapped_glist)
}


#' Turn gene names with date to standard names
#'
#' Fix gene name, for example: '7-Sep' -> 'Sep7'
#' @param gname gene name
#' @return fixed gene name if gene name is in a dated format
#' @export
rename_dated_gene = function(gname){
  if (length(grep("[0-9]+-[Dec|Nov|Oct|Sep|Apr|Mar|Feb|Jun|Jan|May|Aug|Jul]",gname)) > 0){
    eles = stringr::str_split(gname, "-") %>% unlist()
    return(toupper(eles[2] %+% eles[1]))
  } else {
    return(gname)
  }
}
