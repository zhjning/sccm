# Customed pipelines for single-cell analysis
library(Seurat)
library(ggplot2)
library(future)
library(R.filesets)

#' Automatically detection of doublets.
#'
#' @description Further adjustment can use this command:
#' @description so <- DoubletFinder::doubletFinder_v3(so, PCs = selected_dims, pN = pn, pK = pn, nExp = nExp_poi.adj, reuse.pANN = "pANN_pn_pk_cellnumber", sct = FALSE)
#' @description DoubletFinder installed by remotes::install_github('chris-mcginnis-ucsf/DoubletFinder')
#'
#' @param so A seurat object
#' @param ground_truth The attribute name of known group info for the seurat object
#' @param selected_dims The total number of selected dims or a number list.
#' @param pN Default is 25%. The number of generated artificial doublets for DoubletFinder.
#' @param pK Default is 5%. The number of neighbor cells to use for ANN for DoubletFinder.
#' @return A seurat object with doublet annotation added in the meta table
#' @export
auto_doublet_detect = function(so, ground_truth = NULL, selected_dims = 20, pN = 0.25, pK = 0.05){

  if (length(selected_dims) < 2){
    if (length(selected_dims) == 1 & selected_dims > 2){
      selected_dims = 1:selected_dims
    } else {
      print(selected_dims %+% " not recognized. Reset it to 1:20")
      selected_dims = 1:20
    }
  }

  if (is.null(ground_truth) || (! ground_truth %in% colnames(so@meta.data))){
    with_ground_truth = FALSE
  } else {
    with_ground_truth = TRUE
  }

  if (! with_ground_truth){
    ## pK Identification (no ground-truth)
    sweep.res.list_so <- DoubletFinder::paramSweep_v3(so, PCs = selected_dims, sct = FALSE)
    sweep.stats_so <- DoubletFinder::summarizeSweep(sweep.res.list_so, GT = FALSE)
    bcmvn_so <- DoubletFinder::find.pK(sweep.stats_so)
  } else {
    ## pK Identification (ground-truth)
    sweep.res.list_so <- DoubletFinder::paramSweep_v3(so, PCs = selected_dims, sct = FALSE)
    gt.calls <- so@meta.data[rownames(sweep.res.list_so[[1]]), ground_truth]   ## GT is a vector containing "Singlet" and "Doublet" calls recorded using sample multiplexing classification and/or in silico geneotyping results
    sweep.stats_so <- DoubletFinder::summarizeSweep(sweep.res.list_so, GT = TRUE, GT.calls = gt.calls)
    bcmvn_so <- DoubletFinder::find.pK(sweep.stats_so)
  }

  ## Homotypic Doublet Proportion Estimate -------------------------------------------------------------------------------------
  homotypic.prop <- DoubletFinder::modelHomotypic(so@meta.data$seurat_clusters)
  nExp_poi <- round(0.03*nrow(so@meta.data))  ## Assuming 3% doublet formation rate - tailor for your dataset
  nExp_poi.adj <- round(nExp_poi*(1-homotypic.prop))
  print("nExp_poi: " %+% nExp_poi)
  print("nExp_poi.adj: " %+% nExp_poi.adj)

  ## Run DoubletFinder with varying classification stringencies ----------------------------------------------------------------
  so <- DoubletFinder::doubletFinder_v3(so, PCs = selected_dims, pN = pn, pK = pk, nExp = nExp_poi, reuse.pANN = FALSE, sct = FALSE)

  return(so)
}


#' Run seurat pipeline based on given seurat object
#'
#' @param so A seurat object
#' @param label A subgroup
#' @param batch Batch info. Default is NULL.
#' @param SCT Whether to perform SCT transformation. Default is False.
#' @param save Whether to save processed seurat object. Default is False.
#' @param so_dir The dir path to save processed seurat object. Default is NULL.
#' @param prior_metadata The metatable to add to the seurat object.
#' @param treat.cellname Whether to add the seurat project name as a prefix for the cell names. Default is False.
#' @param mtlabel A string or a list of gene names. The name pattern for the recognition of mitochondrial genes.
#' @param assay Default 'RNA'. The name of used assay.
#' @param scale_factor Default 1e6. Normalized range for counts.
#' @param min_bin Default 50. min.bin of FindVariableFeatures.
#' @param min_cutoff Default c(0.01, Inf). min.cutoff of FindVariableFeatures.
#' @param dimnum Default 60. Dim number to use.
#' @param dim_sd Default 1.25. Dim with standard deviation < dim_sd will be not used in the UMAP analysis.
#' @param dim_pval Default 1e-2. Dim with p-value > 1e-2 will be not used in the UMAP analysis.
#' @param clustRes Default 0.8. Resolution for clustering. Range from (0,2)
#' @return The new seurat object
#' @export
run_seurat = function(so, label="", batch=NULL, SCT=F, save=F, so_dir=NULL,
                      prior_metadata=NULL, treat.cellname=F, mtlabel="MT-",min_avg=0.01,
                      assay='RNA', scale_factor=1e6, min_bin=50, min_cutoff=c(0.01, Inf),
                      dimnum=60, dim_sd=1.25, dim_pval=1e-2, clustRes=0.8){
  ## standard
  if (length(mtlabel) > 1){
    mtlist = rownames(so)[grep(mtlabel,toupper(rownames(so)))]
  } else {mtlist = mtlabel}

  opath4seurat = "./"
  if (is.null(so_dir)){
    so_dir = opath4seurat %+% label
  } else {
    so_dir = so_dir %+% "/" %+% label
  }
  createDir(so_dir)

  if (treat.cellname){
    so = Seurat::RenameCells(so, add.cell.id=label)
  }

  all.genes = rownames(so)
  hiexpr.genes = apply(so@assays$RNA@counts,1,mean) ## when the size of dataset is too large, need to separate it into subsets
  so <- Seurat::PercentageFeatureSet(so, features=intersect(mtlist,rownames(so)), col.name="percent.mt")
  ## by traditional Normalization
  # so <- FindVariableFeatures(object=so, selection.method="vst", loess.span=0.3, dispersion.function="FastLogVMR", num.bin=50)
  so <- Seurat::NormalizeData(so, normalization.method="LogNormalize", scale.factor=scale_factor, assay=assay)
  options(future.globals.maxSize=891289600)
  plan(strategy = "multicore", workers = length(unique(so$orig.ident)))
  so <- Seurat::ScaleData(so, vars.to.regress=batch, assay=assay, features=names(hiexpr.genes)[hiexpr.genes > min_avg])
  so <- Seurat::FindVariableFeatures(so, selection.method="mean.var.plot", num.bin=min_bin, mean.cutoff=min_cutoff, assay=assay)
  gc()
  # saveRDS(so, file.path(so_dir,"so.rds"))

  so <- Seurat::RunPCA(so, assay=assay, npcs=dimnum, verbose = FALSE, reduction.name = "pca", reduction.key = assay)
  p_elbowplot_rnapc = Seurat::ElbowPlot(so, ndims=dimnum, reduction="pca")
  dimnum = with(p_elbowplot_rnapc$data, dims[stdev >= dim_sd])
  pdf(file = so_dir %+% "/p_elbow_rnapc.pdf", width=4, height=3)
  print(p_elbowplot_rnapc)
  dev.off()
  gc()

  so <- Seurat::JackStraw(so, num.replicate=5, reduction="pca", dims=max(dimnum))
  so <- Seurat::ScoreJackStraw(so,reduction = "pca",dims=dimnum,score.thresh=dim_pval)
  p_jackstrawplot_pca = Seurat::JackStrawPlot(so, dims=dimnum)
  pdf(file = so_dir %+% "/p_jackstraw_pca.pdf", width=8.6, height=5.4)
  print(p_jackstrawplot_pca)
  dev.off()

  selected_pca_dims = which(so@reductions$pca@jackstraw$overall.p.values[,2] < dim_pval)
  gc()
  if (save){
    dstamp=getdstamp()
    saveRDS(so, file.path(so_dir,"so." %+% dstamp %+% ".rds"))
  }

  if (SCT){
    ## by SCT
    so <- Seurat::SCTransform(so, variable.features.rv.th=1.2, vars.to.regress=batch, do.correct.umi=T, do.center=T, do.scale=T, verbose=F)
    ## PCA
    so <- Seurat::RunPCA(so, assay="SCT", npcs=selected_pca_dims, verbose = FALSE, reduction.name = "sct.pca", reduction.key = "SCT.PC")
    p_elbowplot_sctpc = Seurat::ElbowPlot(so, ndims=selected_pca_dims, reduction="sct.pca")
    pdf(file = so_dir %+% "/p_elbow_stcpc.pdf", width=4, height=3)
    print(p_elbowplot_sctpc)
    dev.off()
  }

  ## reduce dimensions for visualization
  so <- Seurat::RunUMAP(so, dims=selected_pca_dims, verbose=F, seed.use=0)
  so <- Seurat::FindNeighbors(so, dims=selected_pca_dims, compute.SNN=T, prune.SNN=0, verbose=F, force.recalc=T)
  so <- Seurat::FindClusters(so, resolution=clustRes, verbose=F, group.singletons=T, n.iter=10, random.seed=0)
  colorlist = get_random_colorlist(so@meta.data[,"seurat_clusters"])
  p_dimplot <- Seurat::DimPlot(so, reduction="umap", group.by="seurat_clusters", pt.size=0.6, label=TRUE) +
    ggplot2::scale_color_manual(values=colorlist) + NoLegend() + NoAxes()
  ggsave(so_dir %+% "/p_umap.res0.8.pdf", p_dimplot, "pdf", height=5.2, width=5)
  p_umi <- Seurat::FeaturePlot(so, feature="nCount_" %+% assay, pt.size=0.6, order=T) + NoAxes()
  ggsave(so_dir %+% "/p_umap.seqDepth.pdf", p_umi, "pdf", width=5.2, height=5)
  gc()
  if (save){
    saveRDS(so@meta.data, file.path(so_dir,"so.meta." %+% getdstamp() %+% ".rds"))
  }

  ## project-specific module!!
  ## known annotation visualization
  if (!is.null(prior_metadata)){
    #so@meta.data[,c("pre_ct","pre_ct1","pre_ct2","pre_ct3")] <-  prior_metadata[rownames(so@meta.data),
    #                                                                  c("CellTypes","Tissue","Specie","Sample")]
    #if (!is.na(so$pre_ct)){
    #  p_prect1 = UMAPPlot(so, group.by="pre_ct", pt.size=0.6, label=T)+scale_color_manual(values=distinct20)+NoAxes()
    #  p_prect2 = UMAPPlot(so, group.by="pre_ct1", pt.size=0.6, label=T)+scale_color_manual(values=distinct20)+NoAxes()
    #  p_prect3 = UMAPPlot(so, group.by="pre_ct2", pt.size=0.6, label=T)+scale_color_manual(values=distinct20)+NoAxes()
    #  p_prect4 = UMAPPlot(so, group.by="pre_ct3", pt.size=0.6, label=T)+scale_color_manual(values=distinct20)+NoAxes()

    #  ggsave(so_dir %+% "/p_umap.pre_ct1.pdf", p_prect1, "pdf", width=5.2, height=5)
    #  ggsave(so_dir %+% "/p_umap.pre_ct2.pdf", p_prect2, "pdf", width=5.2, height=5)
    #  ggsave(so_dir %+% "/p_umap.pre_ct3.pdf", p_prect3, "pdf", width=5.2, height=5)
    #  ggsave(so_dir %+% "/p_umap.pre_ct4.pdf", p_prect4, "pdf", width=5.2, height=5)
    #}
    for (ifeature in setdiff(grep("Main",colnames(prior_metadata),value=T),c("nCount_" %+% assay,"nFeature_" %+% assay))){
      colorlist = get_random_colorlist(prior_metadata[,ifeature])
      if (uniqlen(prior_metadata[,ifeature]) > 1 & uniqlen(prior_metadata[,ifeature]) < 80){
        p = Seurat::UMAPPlot(so, group.by = ifeature, pt.size=0.6, label=T) +
          ggplot2::scale_color_manual(values=colorlist)+NoAxes()
        ggplot2::ggsave(so_dir %+% "/p_umap" %+% ifeature %+% ".pdf", p, "pdf", width=15, height=5)
      }
    }
  }

  so <- Seurat::BuildClusterTree(so, assay=assay, reduction = "umap")
  all.markers <- Seurat::FindAllMarkers(so, assay=assay, random.seed=19061391)
  marker_filepath = so_dir %+% "/t_markers.cluster.csv"
  write.csv(all.markers, marker_filepath, quote=F)

  ## using scsa perform the automative annotation
  # scsa_annotation = run_scsa(marker_filepath, so@project.name, anno_dir=so_dir)
  # scsa_annotation$ct_table$Z.score[which(is.na(scsa_annotation$ct_table$Z.score))] = -666
  # so$scsa_anno = rep("NA",ncol(so))
  # tmp_scsa_anno = scsa_annotation$ct_table %>% group_by(Cluster) %>% arrange(-Z.score) %>% top_n(n=1) %>% select(Cell.Type, Cluster)
  # scsa_anno = tmp_scsa_anno$Cell.Type
  # names(scsa_anno) = tmp_scsa_anno$Cluster
  # so$scsa_anno = scsa_anno[so$seurat_clusters]
  #
  # p_dimplot <- DimPlot(so, reduction="umap", group.by="scsa_anno", label = TRUE) + NoLegend() + NoAxes()
  # ggsave(so_dir %+% "/p_umap.scsa_anno.pdf", p_dimplot, "pdf", height=5.2, width=5)
  gc()
  if (! save){
    return(so)
  } else {return(NULL)}
}
