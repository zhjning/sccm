## Actions for matrices

#' replicate rows
#'
#' @param x data
#' @param n row number
#' @export
rep.row<-function(x,n){
  matrix(rep(x,each=n),nrow=n)
}

#' replicate columns
#'
#' @param x data
#' @param n column number
#' @export
rep.col<-function(x,n){
  matrix(rep(x,each=n), ncol=n, byrow=TRUE)
}

#' order scaled matrix
#' @export
order_scaledmat = function(exprmat, group=NULL){
  if (is.null(group)){
    scaled_mat = exprmat
  } else {
    scaled_mat = sapply(group, function(igroup){rowSums(exprmat[,igroup])/length(igroup)})
    if (is.null(names(group))){names(group) = paste0("group",1:length(group))}
    colnames(scaled_mat) = names(group)
  }
  glist = c()
  for(i in 1:ncol(scaled_mat)){
    if (i != ncol(scaled_mat)){
      rownames = rownames(scaled_mat)[order(scaled_mat[,i], decreasing=T)]
      tmp_list = sort(scaled_mat[,i], decreasing=T)
      tmp_list = rownames[tmp_list>=0]
      tmp_list = setdiff(tmp_list, glist)
      if (length(tmp_list)>0){
        glist = c(glist, tmp_list)
      }
    } else {
      tmp_list = rownames(scaled_mat)[order(scaled_mat[,i], decreasing=T)]
      tmp_list = setdiff(tmp_list, glist)
      glist = c(glist, tmp_list)
    }
  }
  ordered_exprmat = exprmat[glist, ]
  return(ordered_exprmat)
}


#' Generating a non-duplicated expression matrix
#'
#' To process rownames of gene expression matrix with duplicated names or requires to be named by a new type of ids.
#' For rows that share the same name, averaged row values per column will be applied.
#'
#' @param new_rownames new rownames for the exprmat
#' @param exprmat an expression matrix
#' @return the new expression matrix with new rownames
#' @export
generate_nondup_exprmat = function(new_rownames, exprmat){
  if (length(new_rownames) != nrow(exprmat)){
    print("rownames and matrix row number are different!")
    break
  } else {
    new_exprmat = data.frame()
    sidslist = split(1:nrow(exprmat), new_rownames)
    for (i in 1:length(sidslist)){
      sids = sidslist[[i]]
      if (length(sids) > 1){
        tmpmat = apply(exprmat[sids,],2,function(x) mean(as.numeric(x)))
        new_exprmat = rbind(new_exprmat, tmpmat)
      } else {
        new_exprmat = rbind(new_exprmat, exprmat[sids,])
      }
    }
    rownames(new_exprmat) = names(sidslist)
    colnames(new_exprmat) = colnames(exprmat)
    rm(sidslist, tmpmat)
    return(new_exprmat)
  }
}


#' Scaling a numbered list with the minimum and maximum values
#'
#' The NA values will be omitted in the new list.
#'
#' @param alist A numbered list.
#' @param rangemin The minimum value of the given range.
#' @param rangemax The maximum value of the given range.
#' @return A normalized new list with given ranges.
#' @export
scale_exprList = function(alist,rangemin=0,rangemax=1e6){
  newlist = na.omit(alist)
  ranges = range(newlist)
  newlist = (newlist - ranges[1])/(diff(ranges))
  newlist = newlist/sum(newlist)*(rangemax-rangemin)+rangemin
  alist[!is.na(alist)] = newlist
  return(alist)
}
