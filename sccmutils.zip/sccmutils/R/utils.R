## Setup environment
library(dplyr)
library(progress)
library(R.filesets)

#' @export
`%+%` <- paste0

#' @export
`%++%` <- purrr::partial(.f = paste, sep=".")

#' Clipping results to the clipboard
#'
#' @param rn rowname
#' @param cn colname
#' @param x the data to clip to the clipboard
#' @param mod Default is win. Set it to 'linux' to use linux's clipboard
#' @export
toclipp <- function (x, rn=FALSE, cn=TRUE, mod="win"){
  if (mod == "win"){
    write.table (x, "clipboard-1280", sep="\t", row.names=rn, col.names = cn)
  } else {
      print("Mode " %+% mod %+% ": havn't been developed yet.")
    }
  }

#' Pasting results from the clipboard
#'
#' @param cn colnames
#' @param topaste a boolean lock. Default is False. Manually set it to True for pasting from clipboard.
#' @param mod Default is win. Set it to 'linux' to use linux's clipboard
#' @export
topaste <- function (topaste = FALSE, cn = TRUE, mod="win") {
  if (mod == "win"){
    if(topaste){
      dat = read.table("clipboard",sep="\t",header=cn); return(dat)
    }
  } else {
    print("Mode " %+% mod %+% ": havn't been developed yet.")
  }
}


#' Generate a date stamp to record analysis date
#'
#' Output 2-digit Year + Month + Date with input string length 6.\n Output 4-digit Year + Month + Date with input string length 8.\n Output 4-digit Year Month Date Hour Miniute Second with other numbers.\n
#'
#' @param strlen Assign the format of string length of the output (date)
#' @return A string
#' @export
getdstamp = function(strlen=6){
  if (strlen == 6){
    dstamp=format(Sys.time(),"%Y%m%d") %>% stringr::str_sub(start=3)
  } else if (strlen == 8){
    dstamp=format(Sys.time(),"%Y%m%d")
  } else {
    dstamp=Sys.time() %>% stringr::str_replace_all("-","_") %>% stringr::str_replace_all(":","_") %>% stringr::str_replace_all(" ","_")
  }
  return(dstamp)
}



#' Load package silently
#'
#' Load package ignoring the logs.
#'
#' @param pacName Name of the package to load.
#' @return Null
#' @export
silentload = function(pacName){
  suppressWarnings(suppressMessages(require(pacName)))
}



#' Unique length
#'
#' Return the total number of unique elements in a vector.
#'
#' @param avec A vector.
#' @return The total number of unique elements.
#' @export
uniqlen = function(avec){
  return(length(unique(avec)))
}



#' Generate a named vector
#'
#' Generate a named vector. Extremely useful for idmap tasks. Add new attributes for a data.frame based on the relationship between the new attributes and the known attributes of the data.frame.
#'
#' @param inames names of the vector to return
#' @param ivalues values of the vector to return
#' @return a named vector
#' @export
named_vec = function(inames, ivalues){
  if (length(inames)!=length(ivalues)){
    warning("the lengths of the names and values are not equal! only returns the minimum length.")
    alen = min(length(inames),length(ivalues))
    inames = inames[1:alen]
    ivalues = ivalues[1:alen]
  }
  names(ivalues) = inames
  return(ivalues)
}



#' Turn character vector to number vector
#'
#' Change a character list to a ordered number list which starts with 1 and ends with the total number of unique character elements.
#'
#' @param achar A character list. Like a color list.
#' @return a number list.
#' @export
charvec2ordnumvec = function(achar){
  achar = as.character(achar)
  codemap=named_vec(unique(achar),1:uniqlen(achar))
  return(codemap[achar])
}



#' Turn character vector to number vector
#'
#' Change a character list to a ordered number list which starts with 1 and ends with the total number of unique character elements.
#'
#' @param achar A character list. Like a color list.
#' @return a named number list with original names from the character list.
#' @export
charL2numL = function(achar){
  charList = as.character(achar)
  numList = named_vec(unique(charList),1:uniqlen(charList))[charList]
  return(numList)
}


#' Create a directory
#'
#' If the directory has already been created, ignore the command.\n Otherwise, recursively create the directory.
#'
#' @param pacName Name of the package to load.
#' @return Null
#' @export
createDir = function(dirpath){
  if (!dir.exists(dirpath)){
    dir.create(dirpath, recursive = T)
  }
}


#' Install package manually
#'
#' Wrapped several ways to install packages that unable to be installed by BiocManager::install.
#' R --no-save <<< "install.packages('packageName', repos = 'http://cran.us.r-project.org')"
#'
#' @param packageName The name of the package.
#' @param installMode Default is "-std=c99". Other optinal modes: c99, gnu++11.
#' @param installRepos Default is Null. Other options: YY/XX for online packages in github repos. XX/XX/XX for packages from the local path.
#' @export
install_package_manually = function(packageName, installMode="-std=c99", installRepos=NULL){
  if (is.null(installRepos)){
    if (file.exists(packageName)){
      installType = .Platform$pkgType
      withr::with_makevars(c(PKG_CFLAGS = installMode), #"-std=c11,c99,gnu++11"
                           install.packages(packageName, #"~/workspace/analyses/rejzg/softwares/pdist_1.2.tar.gz"
                                            repos=installRepos,
                                            type=installType), #.Platform$pkgType
                           assignment = "+=")
    } else {
      if (stringr::str_split(packageName,"\\/") %>% unlist %>% length() > 1){
        devtools::install_github(packageName)
      } else {
        installType = "source"
        withr::with_makevars(c(PKG_CFLAGS = installMode), #"-std=c11,c99,gnu++11"
                             install.packages(packageName, #"~/workspace/analyses/rejzg/softwares/pdist_1.2.tar.gz"
                                              repos=installRepos,
                                              type=installType), #.Platform$pkgType
                             assignment = "+=")
      }
    }
  } else if (installRepos == "cran"){
    install.packages(packageName)
  } else if (installRepos == "bioconductor"){
    BiocManager::install(packageName)
  }
}


#' clear the workspace and release the space
#'
#' assign a specific keyword or a list of variables to realse
#'
#' @param kw keyword
#' @param varlist a list of variables to remove
#' @param prep Default is True, generate the variables to remove. If False, remove the variables.
#' @return NULL or the variables to remove if prep is True.
#' @export
clear_workspace = function(kw = NULL, varlist = NULL, prep = T){
  if (prep==T){
    return(grep(kw,ls(envir = globalenv()),value=T))
  } else {
    if ((! is.null(kw)) | (! is.null(varlist))){
      if(is.null(varlist)){
        varlist = grep(kw,ls(),value=T)
      }
      rm(list=varlist, envir = globalenv())
    }
  }
}


#' mutiple parallel
#'
#' @param func: function to parallel
#' @param ..." dynamic params for function
#' @param MoreArgs: static params for function (list)
#' @return list
#' @export
multi_parallel <- function(func, ..., MoreArgs=NULL){

  library(foreach)
  library(doParallel)
  library(parallel)

  cores <- detectCores(logical = FALSE)
  cl <- makeCluster(cores)
  registerDoParallel(cl)
  dots <- list(...)
  result <- foreach(i=seq(length(dots[[1]])), .combine = c) %dopar%
    do.call(func, c(lapply(dots,`[`, i, MoreArgs)))
  stopCluster(cl)
  return(result)
}
